# Kernel

This directory contains two different protocols for the CBR: TCP-UDP and UDP-UDP. Each subdirectory contains a README detailing its implementation. Common sections are duplicated for ease of reading.