#ifndef __CBR
#define __CBR

#define SERVERS 2

struct ip {
  __u32 addr;
};

#endif